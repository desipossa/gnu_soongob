<?php
$cate_num = 1;
$page_num = 2;
$cate_tit = '순곱이네 스토리';
$page_tit = '체인사업부 찾아오시는길';
include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>

<div class="con_wrap">

</div>

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>