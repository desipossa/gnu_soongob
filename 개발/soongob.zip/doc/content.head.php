<div class="content_head">    
    <div class="con">
        <figure>
            <img src="../images/logo.png" alt="">
        </figure>
        <strong><?=$page_tit;?></strong>
        <p><?=$SLG;?></p>
    </div>
</div>