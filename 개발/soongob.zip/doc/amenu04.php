<ul class="depth2">
    <li><a href="">순곱이네 매장찾기</a></li>
    <li><a href="h">순곱이네 오픈 예정점</a></li>
    <li><a href="">순곱이네 구인</a></li>
</ul>