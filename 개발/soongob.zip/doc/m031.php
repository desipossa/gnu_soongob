<?php
$cate_num = 3;
$page_num = 1;
$cate_tit = '깔끄미청소';
$page_tit = '이사/상가청소';
include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>

<? include G5_THEME_PATH.'/doc/content.head.php';?>

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>