<ul class="depth2">
    <li><a href="">순곱이네 메뉴</a></li>
</ul>