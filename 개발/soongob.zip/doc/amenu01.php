<ul class="depth2">
    <li><a href="<?=G5_THEME_URL;?>/doc/m011.php">순곱이네 스토리</a></li>
    <li><a href="<?=G5_THEME_URL;?>/doc/m012.php">체인사업부 찾아오시는길</a></li>
</ul>